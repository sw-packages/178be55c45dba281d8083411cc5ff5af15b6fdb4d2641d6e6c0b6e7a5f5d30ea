/////////////////////////////////////////////////////////////////////////////
// Name:        wx/dcps.h
// Purpose:     wxPostScriptDC base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_DCPS_H_BASE_
#define _WX_DCPS_H_BASE_

#include "wx/generic/dcpsg.h"

#endif

